import{S as e,j as o,n as t}from"./qDG42ys9.js";const d=e((r,s)=>{const{user:a}=o();if(!a.value||a.value.role!=="admin")return t("/dashboard")});export{d as default};
