import{f as a}from"./pMK9VmZY.js";import{f as o}from"./Cl4ISXQJ.js";const f=(r,t="dd/MM/yyyy")=>r?a(new Date(r),t,{locale:o}):"",m=r=>f(r,"d MMM yyyy");export{f as a,m as f};
