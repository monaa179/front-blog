import{g as e,n as s}from"./qDG42ys9.js";const o={__name:"index",async setup(n){let t,a;return[t,a]=e(()=>s("/dashboard")),await t,a(),()=>{}}};export{o as default};
