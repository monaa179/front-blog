function serializeBigInt(obj) {
  if (obj === null || obj === void 0) {
    return obj;
  }
  if (typeof obj === "bigint") {
    return Number(obj);
  }
  if (obj instanceof Date) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => serializeBigInt(item));
  }
  if (typeof obj === "object") {
    const result = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        result[key] = serializeBigInt(obj[key]);
      }
    }
    return result;
  }
  return obj;
}

export { serializeBigInt as s };
//# sourceMappingURL=serialize.mjs.map
